export interface Policy {
  id: string;
  title: string;
  url: string;
  description: string;
  type: string;
}
