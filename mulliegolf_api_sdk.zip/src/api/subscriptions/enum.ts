export enum ProviderType {
  IOS = 'ios',
  ANDROID = 'android',
}

export enum PackageLevel {
  FREE = 1,
  HACKER = 2,
  TOUR = 3,
  BUSINESS = 4,
}
