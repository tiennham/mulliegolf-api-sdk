// import { expect } from 'chai';
// import { describe, it } from 'mocha';

// import { api, getAuthToken } from '../config.test';

// describe('Index Auth', () => {
//   it('should logged in', async () => {
//     const r: any = await api.auth.login('manbg01@yopmail.com', '123456@aA');
//     expect(getAuthToken(r)).not.empty;

//     const feeds: any = await api.feeds.getFeeds();
//     console.log(feeds['results'][1]['keywords']);
//   });
// });
