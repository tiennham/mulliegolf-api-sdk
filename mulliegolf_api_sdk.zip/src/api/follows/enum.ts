export enum TypeFollows {
  USER = 'USER',
  BRAND = 'BRAND',
}
