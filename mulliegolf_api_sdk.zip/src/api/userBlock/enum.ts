export enum ReportType {
  USER = 'USER',
  PRODUCT = 'PRODUCT',
}

export enum ReasonType {
  USER = 'USER',
  PRODUCT = 'PRODUCT',
}
