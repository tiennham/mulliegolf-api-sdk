export enum SearchType {
  CLASSIFICATION = 'CLASSIFICATION',
  KEY = 'KEY',
  VALUE = 'VALUE',
}
