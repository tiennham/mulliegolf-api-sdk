export enum TypeProviderShipment {
  USPS = 'USPS',
  FEDEX = 'FEDEX',
}
